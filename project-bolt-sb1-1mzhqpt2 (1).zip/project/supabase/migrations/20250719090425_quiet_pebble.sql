/*
  # ESSENZA Perfume Database Schema

  1. New Tables
    - `perfumes`
      - `id` (uuid, primary key)
      - `name` (text)
      - `brand` (text)
      - `price` (decimal)
      - `original_price` (decimal, nullable)
      - `image` (text)
      - `description` (text)
      - `top_notes` (text array)
      - `middle_notes` (text array)
      - `base_notes` (text array)
      - `category` (text)
      - `intensity` (text)
      - `occasion` (text)
      - `season` (text)
      - `gender` (text)
      - `rating` (decimal)
      - `reviews` (integer)
      - `in_stock` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `quiz_results`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `answers` (jsonb)
      - `personality_type` (text)
      - `recommended_perfumes` (uuid array)
      - `created_at` (timestamp)

    - `cart_items`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `perfume_id` (uuid, foreign key to perfumes)
      - `quantity` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `wishlist_items`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `perfume_id` (uuid, foreign key to perfumes)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Public read access for perfumes
*/

-- Create perfumes table
CREATE TABLE IF NOT EXISTS perfumes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  brand text NOT NULL DEFAULT 'ESSENZA',
  price decimal(10,2) NOT NULL,
  original_price decimal(10,2),
  image text NOT NULL,
  description text NOT NULL,
  top_notes text[] NOT NULL DEFAULT '{}',
  middle_notes text[] NOT NULL DEFAULT '{}',
  base_notes text[] NOT NULL DEFAULT '{}',
  category text NOT NULL CHECK (category IN ('fresh', 'floral', 'woody', 'oriental', 'citrus')),
  intensity text NOT NULL CHECK (intensity IN ('light', 'medium', 'strong')),
  occasion text NOT NULL CHECK (occasion IN ('day', 'night', 'special', 'casual')),
  season text NOT NULL CHECK (season IN ('spring', 'summer', 'autumn', 'winter', 'all')),
  gender text NOT NULL CHECK (gender IN ('men', 'women', 'unisex')),
  rating decimal(2,1) NOT NULL DEFAULT 4.0 CHECK (rating >= 0 AND rating <= 5),
  reviews integer NOT NULL DEFAULT 0,
  in_stock boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create quiz_results table
CREATE TABLE IF NOT EXISTS quiz_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  answers jsonb NOT NULL,
  personality_type text NOT NULL,
  recommended_perfumes uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  perfume_id uuid REFERENCES perfumes(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, perfume_id)
);

-- Create wishlist_items table
CREATE TABLE IF NOT EXISTS wishlist_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  perfume_id uuid REFERENCES perfumes(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, perfume_id)
);

-- Enable Row Level Security
ALTER TABLE perfumes ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE wishlist_items ENABLE ROW LEVEL SECURITY;

-- Policies for perfumes (public read, admin write)
CREATE POLICY "Anyone can read perfumes"
  ON perfumes
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert perfumes"
  ON perfumes
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update perfumes"
  ON perfumes
  FOR UPDATE
  TO authenticated
  USING (true);

-- Policies for quiz_results
CREATE POLICY "Users can read own quiz results"
  ON quiz_results
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own quiz results"
  ON quiz_results
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policies for cart_items
CREATE POLICY "Users can manage own cart items"
  ON cart_items
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policies for wishlist_items
CREATE POLICY "Users can manage own wishlist items"
  ON wishlist_items
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_perfumes_category ON perfumes(category);
CREATE INDEX IF NOT EXISTS idx_perfumes_price ON perfumes(price);
CREATE INDEX IF NOT EXISTS idx_perfumes_rating ON perfumes(rating);
CREATE INDEX IF NOT EXISTS idx_cart_items_user_id ON cart_items(user_id);
CREATE INDEX IF NOT EXISTS idx_wishlist_items_user_id ON wishlist_items(user_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_perfumes_updated_at
  BEFORE UPDATE ON perfumes
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_cart_items_updated_at
  BEFORE UPDATE ON cart_items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();