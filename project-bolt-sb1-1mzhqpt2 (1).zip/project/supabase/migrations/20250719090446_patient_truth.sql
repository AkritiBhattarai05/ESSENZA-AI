/*
  # Seed ESSENZA Perfume Data

  1. Insert sample perfume data
    - Premium fragrance collection
    - Diverse categories and notes
    - Realistic pricing and ratings
*/

-- Insert sample perfumes
INSERT INTO perfumes (
  name, brand, price, original_price, image, description,
  top_notes, middle_notes, base_notes,
  category, intensity, occasion, season, gender, rating, reviews, in_stock
) VALUES
(
  'Midnight Bloom', 'ESSENZA', 129.00, 159.00,
  'https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=400',
  'An intoxicating blend of night-blooming jasmine and dark vanilla, perfect for evening elegance.',
  ARRAY['Bergamot', 'Black Currant', 'Pink Pepper'],
  ARRAY['Jasmine', 'Rose', 'Lily of the Valley'],
  ARRAY['Vanilla', 'Sandalwood', 'Musk'],
  'floral', 'strong', 'night', 'autumn', 'women', 4.8, 234, true
),
(
  'Ocean Breeze', 'ESSENZA', 89.00, NULL,
  'https://images.pexels.com/photos/1334597/pexels-photo-1334597.jpeg?auto=compress&cs=tinysrgb&w=400',
  'Fresh and invigorating, capturing the essence of a Mediterranean coastline.',
  ARRAY['Sea Salt', 'Lemon', 'Eucalyptus'],
  ARRAY['Lavender', 'Geranium', 'Mint'],
  ARRAY['Driftwood', 'Amber', 'White Musk'],
  'fresh', 'light', 'day', 'summer', 'unisex', 4.6, 189, true
),
(
  'Golden Sunset', 'ESSENZA', 149.00, NULL,
  'https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=400',
  'Warm and luxurious, with rich amber and exotic spices that evoke golden hour.',
  ARRAY['Cardamom', 'Saffron', 'Orange Blossom'],
  ARRAY['Oud', 'Rose', 'Cinnamon'],
  ARRAY['Amber', 'Tobacco', 'Leather'],
  'oriental', 'strong', 'special', 'winter', 'unisex', 4.9, 312, true
),
(
  'Forest Path', 'ESSENZA', 109.00, NULL,
  'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=400',
  'Earthy and sophisticated, inspired by ancient forests and weathered wood.',
  ARRAY['Pine', 'Juniper', 'Grapefruit'],
  ARRAY['Cedar', 'Cypress', 'Sage'],
  ARRAY['Sandalwood', 'Vetiver', 'Moss'],
  'woody', 'medium', 'casual', 'all', 'men', 4.7, 156, true
),
(
  'Citrus Dreams', 'ESSENZA', 79.00, NULL,
  'https://images.pexels.com/photos/1375849/pexels-photo-1375849.jpeg?auto=compress&cs=tinysrgb&w=400',
  'Bright and energizing, a perfect blend of citrus fruits and fresh herbs.',
  ARRAY['Lemon', 'Lime', 'Grapefruit'],
  ARRAY['Basil', 'Thyme', 'Green Apple'],
  ARRAY['White Tea', 'Cedarwood', 'Clean Musk'],
  'citrus', 'light', 'day', 'spring', 'unisex', 4.5, 98, true
),
(
  'Velvet Rose', 'ESSENZA', 139.00, NULL,
  'https://images.pexels.com/photos/1557980/pexels-photo-1557980.jpeg?auto=compress&cs=tinysrgb&w=400',
  'Luxurious and romantic, featuring the finest Bulgarian rose petals.',
  ARRAY['Red Rose', 'Peony', 'Blackcurrant'],
  ARRAY['Damask Rose', 'Peach', 'Magnolia'],
  ARRAY['Cashmere Wood', 'Vanilla', 'Soft Musk'],
  'floral', 'medium', 'special', 'spring', 'women', 4.8, 267, false
),
(
  'Mystic Oud', 'ESSENZA', 189.00, NULL,
  'https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=400',
  'An exotic and mysterious blend featuring rare oud wood and precious spices.',
  ARRAY['Black Pepper', 'Cardamom', 'Bergamot'],
  ARRAY['Oud Wood', 'Rose', 'Saffron'],
  ARRAY['Amber', 'Patchouli', 'Vanilla'],
  'oriental', 'strong', 'night', 'winter', 'unisex', 4.9, 145, true
),
(
  'Spring Garden', 'ESSENZA', 95.00, NULL,
  'https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=400',
  'A delicate bouquet of spring flowers with a touch of green freshness.',
  ARRAY['Green Leaves', 'Dewdrops', 'Lemon'],
  ARRAY['Peony', 'Lily', 'Freesia'],
  ARRAY['White Musk', 'Cedar', 'Soft Amber'],
  'floral', 'light', 'day', 'spring', 'women', 4.6, 203, true
),
(
  'Urban Legend', 'ESSENZA', 119.00, 139.00,
  'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=400',
  'Modern and edgy, capturing the energy of city life with smoky undertones.',
  ARRAY['Black Tea', 'Ginger', 'Bergamot'],
  ARRAY['Smoky Incense', 'Violet', 'Spices'],
  ARRAY['Leather', 'Patchouli', 'Dark Musk'],
  'woody', 'strong', 'night', 'autumn', 'men', 4.4, 87, true
),
(
  'Tropical Paradise', 'ESSENZA', 99.00, NULL,
  'https://images.pexels.com/photos/1375849/pexels-photo-1375849.jpeg?auto=compress&cs=tinysrgb&w=400',
  'Escape to paradise with this vibrant blend of tropical fruits and coconut.',
  ARRAY['Pineapple', 'Mango', 'Coconut'],
  ARRAY['Frangipani', 'Ylang-Ylang', 'Hibiscus'],
  ARRAY['Vanilla', 'Sandalwood', 'Solar Musk'],
  'citrus', 'medium', 'day', 'summer', 'women', 4.3, 156, true
);