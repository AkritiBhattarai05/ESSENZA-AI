import React, { useState } from 'react';
import { AuthProvider } from './hooks/useAuth';
import Header from './components/Header';
import Hero from './components/Hero';
import Quiz from './components/Quiz';
import Products from './components/Products';
import About from './components/About';

function App() {
  const [currentSection, setCurrentSection] = useState('home');
  const [cartItems, setCartItems] = useState([]);
  const [wishlistItems, setWishlistItems] = useState([]);

  const handleAddToCart = (perfume) => {
    setCartItems(prev => {
      const existingItem = prev.find(item => item.perfume.id === perfume.id);
      if (existingItem) {
        return prev.map(item =>
          item.perfume.id === perfume.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { perfume, quantity: 1 }];
    });
  };

  const handleAddToWishlist = (perfume) => {
    setWishlistItems(prev => {
      const isAlreadyWishlisted = prev.some(item => item.id === perfume.id);
      if (isAlreadyWishlisted) {
        return prev.filter(item => item.id !== perfume.id);
      }
      return [...prev, perfume];
    });
  };

  const totalCartItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const renderCurrentSection = () => {
    switch (currentSection) {
      case 'home':
        return (
          <Hero
            onStartQuiz={() => setCurrentSection('quiz')}
            onViewProducts={() => setCurrentSection('products')}
          />
        );
      case 'quiz':
        return (
          <Quiz
            onAddToCart={handleAddToCart}
            onAddToWishlist={handleAddToWishlist}
          />
        );
      case 'products':
        return (
          <Products
            onAddToCart={handleAddToCart}
            onAddToWishlist={handleAddToWishlist}
          />
        );
      case 'about':
        return <About />;
      default:
        return (
          <Hero
            onStartQuiz={() => setCurrentSection('quiz')}
            onViewProducts={() => setCurrentSection('products')}
          />
        );
    }
  };

  return (
    <AuthProvider>
      <div className="min-h-screen bg-white">
        <Header
          currentSection={currentSection}
          onSectionChange={setCurrentSection}
          cartItems={totalCartItems}
          wishlistItems={wishlistItems.length}
        />
        <main className="pt-16">
          {renderCurrentSection()}
        </main>
      </div>
    </AuthProvider>
  );
}

export default App;