// Perfume data structure
export const PerfumeCategories = {
  FRESH: 'fresh',
  FLORAL: 'floral',
  WOODY: 'woody',
  ORIENTAL: 'oriental',
  CITRUS: 'citrus'
};

export const Intensities = {
  LIGHT: 'light',
  MEDIUM: 'medium',
  STRONG: 'strong'
};

export const Occasions = {
  DAY: 'day',
  NIGHT: 'night',
  SPECIAL: 'special',
  CASUAL: 'casual'
};

export const Seasons = {
  SPRING: 'spring',
  SUMMER: 'summer',
  AUTUMN: 'autumn',
  WINTER: 'winter',
  ALL: 'all'
};

export const Genders = {
  MEN: 'men',
  WOMEN: 'women',
  UNISEX: 'unisex'
};