export interface Perfume {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  image: string;
  description: string;
  notes: {
    top: string[];
    middle: string[];
    base: string[];
  };
  category: 'fresh' | 'floral' | 'woody' | 'oriental' | 'citrus';
  intensity: 'light' | 'medium' | 'strong';
  occasion: 'day' | 'night' | 'special' | 'casual';
  season: 'spring' | 'summer' | 'autumn' | 'winter' | 'all';
  gender: 'men' | 'women' | 'unisex';
  rating: number;
  reviews: number;
  inStock: boolean;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: QuizOption[];
  category: 'preference' | 'lifestyle' | 'occasion' | 'personality';
}

export interface QuizOption {
  id: string;
  text: string;
  value: string;
  weight: Record<string, number>;
}

export interface QuizResult {
  recommendations: Perfume[];
  personality: string;
  description: string;
}

export interface CartItem {
  perfume: Perfume;
  quantity: number;
}