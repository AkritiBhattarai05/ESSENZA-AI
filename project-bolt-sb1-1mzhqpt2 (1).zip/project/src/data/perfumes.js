export const perfumes = [
  {
    id: '1',
    name: 'Midnight Bloom',
    brand: 'ESSENZA',
    price: 129,
    originalPrice: 159,
    image: 'https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'An intoxicating blend of night-blooming jasmine and dark vanilla, perfect for evening elegance.',
    notes: {
      top: ['Bergamot', 'Black Currant', 'Pink Pepper'],
      middle: ['Jasmine', 'Rose', 'Lily of the Valley'],
      base: ['Vanilla', 'Sandalwood', 'Musk']
    },
    category: 'floral',
    intensity: 'strong',
    occasion: 'night',
    season: 'autumn',
    gender: 'women',
    rating: 4.8,
    reviews: 234,
    inStock: true
  },
  {
    id: '2',
    name: 'Ocean Breeze',
    brand: 'ESSENZA',
    price: 89,
    image: 'https://images.pexels.com/photos/1334597/pexels-photo-1334597.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Fresh and invigorating, capturing the essence of a Mediterranean coastline.',
    notes: {
      top: ['Sea Salt', 'Lemon', 'Eucalyptus'],
      middle: ['Lavender', 'Geranium', 'Mint'],
      base: ['Driftwood', 'Amber', 'White Musk']
    },
    category: 'fresh',
    intensity: 'light',
    occasion: 'day',
    season: 'summer',
    gender: 'unisex',
    rating: 4.6,
    reviews: 189,
    inStock: true
  },
  {
    id: '3',
    name: 'Golden Sunset',
    brand: 'ESSENZA',
    price: 149,
    image: 'https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Warm and luxurious, with rich amber and exotic spices that evoke golden hour.',
    notes: {
      top: ['Cardamom', 'Saffron', 'Orange Blossom'],
      middle: ['Oud', 'Rose', 'Cinnamon'],
      base: ['Amber', 'Tobacco', 'Leather']
    },
    category: 'oriental',
    intensity: 'strong',
    occasion: 'special',
    season: 'winter',
    gender: 'unisex',
    rating: 4.9,
    reviews: 312,
    inStock: true
  },
  {
    id: '4',
    name: 'Forest Path',
    brand: 'ESSENZA',
    price: 109,
    image: 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Earthy and sophisticated, inspired by ancient forests and weathered wood.',
    notes: {
      top: ['Pine', 'Juniper', 'Grapefruit'],
      middle: ['Cedar', 'Cypress', 'Sage'],
      base: ['Sandalwood', 'Vetiver', 'Moss']
    },
    category: 'woody',
    intensity: 'medium',
    occasion: 'casual',
    season: 'all',
    gender: 'men',
    rating: 4.7,
    reviews: 156,
    inStock: true
  },
  {
    id: '5',
    name: 'Citrus Dreams',
    brand: 'ESSENZA',
    price: 79,
    image: 'https://images.pexels.com/photos/1375849/pexels-photo-1375849.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Bright and energizing, a perfect blend of citrus fruits and fresh herbs.',
    notes: {
      top: ['Lemon', 'Lime', 'Grapefruit'],
      middle: ['Basil', 'Thyme', 'Green Apple'],
      base: ['White Tea', 'Cedarwood', 'Clean Musk']
    },
    category: 'citrus',
    intensity: 'light',
    occasion: 'day',
    season: 'spring',
    gender: 'unisex',
    rating: 4.5,
    reviews: 98,
    inStock: true
  },
  {
    id: '6',
    name: 'Velvet Rose',
    brand: 'ESSENZA',
    price: 139,
    image: 'https://images.pexels.com/photos/1557980/pexels-photo-1557980.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Luxurious and romantic, featuring the finest Bulgarian rose petals.',
    notes: {
      top: ['Red Rose', 'Peony', 'Blackcurrant'],
      middle: ['Damask Rose', 'Peach', 'Magnolia'],
      base: ['Cashmere Wood', 'Vanilla', 'Soft Musk']
    },
    category: 'floral',
    intensity: 'medium',
    occasion: 'special',
    season: 'spring',
    gender: 'women',
    rating: 4.8,
    reviews: 267,
    inStock: false
  },
  {
    id: '7',
    name: 'Mystic Oud',
    brand: 'ESSENZA',
    price: 189,
    image: 'https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'An exotic and mysterious blend featuring rare oud wood and precious spices.',
    notes: {
      top: ['Black Pepper', 'Cardamom', 'Bergamot'],
      middle: ['Oud Wood', 'Rose', 'Saffron'],
      base: ['Amber', 'Patchouli', 'Vanilla']
    },
    category: 'oriental',
    intensity: 'strong',
    occasion: 'night',
    season: 'winter',
    gender: 'unisex',
    rating: 4.9,
    reviews: 145,
    inStock: true
  },
  {
    id: '8',
    name: 'Spring Garden',
    brand: 'ESSENZA',
    price: 95,
    image: 'https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'A delicate bouquet of spring flowers with a touch of green freshness.',
    notes: {
      top: ['Green Leaves', 'Dewdrops', 'Lemon'],
      middle: ['Peony', 'Lily', 'Freesia'],
      base: ['White Musk', 'Cedar', 'Soft Amber']
    },
    category: 'floral',
    intensity: 'light',
    occasion: 'day',
    season: 'spring',
    gender: 'women',
    rating: 4.6,
    reviews: 203,
    inStock: true
  }
];