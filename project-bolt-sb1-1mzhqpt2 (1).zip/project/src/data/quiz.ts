import { QuizQuestion } from '../types';

export const quizQuestions: QuizQuestion[] = [
  {
    id: '1',
    question: 'What time of day do you feel most confident?',
    category: 'lifestyle',
    options: [
      {
        id: '1a',
        text: 'Early morning with fresh coffee',
        value: 'morning',
        weight: { fresh: 3, citrus: 2, light: 2 }
      },
      {
        id: '1b',
        text: 'Golden hour before sunset',
        value: 'evening',
        weight: { oriental: 2, woody: 2, medium: 2 }
      },
      {
        id: '1c',
        text: 'Deep night under the stars',
        value: 'night',
        weight: { floral: 3, oriental: 2, strong: 3 }
      }
    ]
  },
  {
    id: '2',
    question: 'Which environment makes you feel most at peace?',
    category: 'preference',
    options: [
      {
        id: '2a',
        text: 'A blooming garden in spring',
        value: 'garden',
        weight: { floral: 3, fresh: 2, spring: 3 }
      },
      {
        id: '2b',
        text: 'A secluded forest trail',
        value: 'forest',
        weight: { woody: 3, fresh: 1, all: 2 }
      },
      {
        id: '2c',
        text: 'An exotic spice market',
        value: 'market',
        weight: { oriental: 3, strong: 2, special: 2 }
      },
      {
        id: '2d',
        text: 'A pristine beach at sunrise',
        value: 'beach',
        weight: { fresh: 3, citrus: 2, summer: 3 }
      }
    ]
  },
  {
    id: '3',
    question: 'Your ideal evening out would be:',
    category: 'occasion',
    options: [
      {
        id: '3a',
        text: 'An elegant dinner at a fine restaurant',
        value: 'elegant',
        weight: { floral: 2, oriental: 2, special: 3, strong: 2 }
      },
      {
        id: '3b',
        text: 'A casual gathering with close friends',
        value: 'casual',
        weight: { fresh: 2, citrus: 2, casual: 3, light: 2 }
      },
      {
        id: '3c',
        text: 'An exclusive art gallery opening',
        value: 'sophisticated',
        weight: { woody: 2, oriental: 2, special: 2, medium: 2 }
      },
      {
        id: '3d',
        text: 'A cozy night in with good books',
        value: 'intimate',
        weight: { floral: 2, woody: 1, casual: 2, light: 1 }
      }
    ]
  },
  {
    id: '4',
    question: 'Which word best describes your personality?',
    category: 'personality',
    options: [
      {
        id: '4a',
        text: 'Adventurous and spontaneous',
        value: 'adventurous',
        weight: { fresh: 2, citrus: 2, day: 2, light: 1 }
      },
      {
        id: '4b',
        text: 'Romantic and dreamy',
        value: 'romantic',
        weight: { floral: 3, special: 2, medium: 2 }
      },
      {
        id: '4c',
        text: 'Sophisticated and mysterious',
        value: 'mysterious',
        weight: { oriental: 3, woody: 1, night: 2, strong: 2 }
      },
      {
        id: '4d',
        text: 'Confident and bold',
        value: 'bold',
        weight: { oriental: 2, woody: 2, strong: 3, special: 1 }
      }
    ]
  },
  {
    id: '5',
    question: 'What season resonates most with your spirit?',
    category: 'preference',
    options: [
      {
        id: '5a',
        text: 'Spring - renewal and fresh beginnings',
        value: 'spring',
        weight: { floral: 3, fresh: 2, spring: 3, light: 2 }
      },
      {
        id: '5b',
        text: 'Summer - vibrant energy and warmth',
        value: 'summer',
        weight: { citrus: 3, fresh: 2, summer: 3, day: 2 }
      },
      {
        id: '5c',
        text: 'Autumn - rich depth and transformation',
        value: 'autumn',
        weight: { woody: 2, oriental: 2, autumn: 3, medium: 2 }
      },
      {
        id: '5d',
        text: 'Winter - cozy intimacy and contemplation',
        value: 'winter',
        weight: { oriental: 3, woody: 2, winter: 3, strong: 2 }
      }
    ]
  }
];