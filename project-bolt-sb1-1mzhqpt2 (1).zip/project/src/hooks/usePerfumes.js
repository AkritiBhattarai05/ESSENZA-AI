import { useState, useEffect } from 'react';
import { perfumeService } from '../lib/supabase';

export const usePerfumes = (filters = {}) => {
  const [perfumes, setPerfumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPerfumes = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const data = await perfumeService.searchPerfumes(filters.search, {
          category: filters.category,
          intensity: filters.intensity,
          minPrice: filters.priceRange?.[0],
          maxPrice: filters.priceRange?.[1],
          sortBy: filters.sortBy
        });
        
        setPerfumes(data || []);
      } catch (err) {
        setError(err.message);
        console.error('Error fetching perfumes:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPerfumes();
  }, [
    filters.search,
    filters.category,
    filters.intensity,
    filters.priceRange?.[0],
    filters.priceRange?.[1],
    filters.sortBy
  ]);

  return { perfumes, loading, error, refetch: () => fetchPerfumes() };
};

export const usePerfume = (id) => {
  const [perfume, setPerfume] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!id) return;

    const fetchPerfume = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await perfumeService.getPerfumeById(id);
        setPerfume(data);
      } catch (err) {
        setError(err.message);
        console.error('Error fetching perfume:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPerfume();
  }, [id]);

  return { perfume, loading, error };
};