import React from 'react';
import { Award, Heart, Sparkles, Users } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: <Heart className="w-8 h-8 text-purple-600" />,
      title: 'Crafted with Passion',
      description: 'Each fragrance is carefully developed by master perfumers who understand the art of scent creation.'
    },
    {
      icon: <Award className="w-8 h-8 text-purple-600" />,
      title: 'Premium Quality',
      description: 'We use only the finest ingredients sourced from around the world to ensure exceptional quality.'
    },
    {
      icon: <Sparkles className="w-8 h-8 text-purple-600" />,
      title: 'Unique Blends',
      description: 'Our signature fragrances are exclusive compositions that you won\'t find anywhere else.'
    },
    {
      icon: <Users className="w-8 h-8 text-purple-600" />,
      title: 'Personal Journey',
      description: 'We believe every person deserves a signature scent that tells their unique story.'
    }
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-amber-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            About ESSENZA
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Founded with a passion for the art of perfumery, ESSENZA represents the perfect harmony between tradition and innovation. We believe that fragrance is more than just a scent—it's a personal signature, a memory, and an emotion captured in a bottle.
          </p>
        </div>

        {/* Hero Image */}
        <div className="mb-16">
          <div className="relative h-96 rounded-3xl overflow-hidden">
            <img
              src="https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=1920"
              alt="Perfume bottles in elegant setting"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            <div className="absolute bottom-8 left-8 text-white">
              <h2 className="text-3xl font-bold mb-2">The Art of Scent</h2>
              <p className="text-lg opacity-90">Where luxury meets craftsmanship</p>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Story Section */}
        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              Our Story
            </h2>
            <div className="space-y-6 text-lg text-gray-700 leading-relaxed">
              <p>
                ESSENZA was born from a simple yet profound belief: that every person has a unique essence that deserves to be celebrated through fragrance. Our journey began in the heart of Grasse, France, where we learned the ancient art of perfumery from master craftsmen who had dedicated their lives to creating olfactory masterpieces.
              </p>
              <p>
                What sets us apart is our commitment to personalization. We understand that choosing a fragrance is deeply personal—it's about finding a scent that resonates with your soul, complements your personality, and becomes an integral part of your identity. That's why we developed our intelligent fragrance quiz, designed to understand your preferences and guide you to your perfect match.
              </p>
              <p>
                Today, ESSENZA continues to push the boundaries of traditional perfumery, combining time-honored techniques with modern innovation. Each bottle in our collection tells a story, evokes an emotion, and creates a lasting impression that goes far beyond the initial spray.
              </p>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="mt-16 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">
            Our Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-purple-100 to-purple-200 rounded-2xl p-8">
              <h3 className="text-xl font-bold text-purple-900 mb-4">Authenticity</h3>
              <p className="text-purple-800">
                We believe in creating genuine, original fragrances that reflect true artistry and craftsmanship.
              </p>
            </div>
            <div className="bg-gradient-to-br from-amber-100 to-amber-200 rounded-2xl p-8">
              <h3 className="text-xl font-bold text-amber-900 mb-4">Quality</h3>
              <p className="text-amber-800">
                Only the finest ingredients make it into our bottles, ensuring exceptional quality in every spray.
              </p>
            </div>
            <div className="bg-gradient-to-br from-purple-100 to-amber-100 rounded-2xl p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Innovation</h3>
              <p className="text-gray-800">
                We continuously explore new frontiers in fragrance creation while respecting traditional techniques.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;