import React, { useState } from 'react';
import { ChevronRight, ChevronLeft, Sparkles, Heart, RefreshCw, Award } from 'lucide-react';
import { quizQuestions } from '../data/quiz';
import { usePerfumes } from '../hooks/usePerfumes';
import { useAuth } from '../hooks/useAuth';
import { quizService } from '../lib/supabase';
import ProductCard from './ProductCard';

const Quiz = ({ onAddToCart, onAddToWishlist }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState(null);
  const { user } = useAuth();
  const { perfumes } = usePerfumes();

  const handleAnswer = (questionId, optionId) => {
    setAnswers(prev => ({ ...prev, [questionId]: optionId }));
  };

  const nextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResults();
    }
  };

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const calculateResults = () => {
    const scores = {};
    
    Object.entries(answers).forEach(([questionId, optionId]) => {
      const question = quizQuestions.find(q => q.id === questionId);
      const option = question?.options.find(o => o.id === optionId);
      
      if (option) {
        Object.entries(option.weight).forEach(([key, value]) => {
          scores[key] = (scores[key] || 0) + value;
        });
      }
    });

    // Find matching perfumes based on scores
    const matchedPerfumes = perfumes
      .map(perfume => {
        let matchScore = 0;
        
        // Category matching
        if (scores[perfume.category]) {
          matchScore += scores[perfume.category] * 2;
        }
        
        // Intensity matching
        if (scores[perfume.intensity]) {
          matchScore += scores[perfume.intensity] * 1.5;
        }
        
        // Occasion matching
        if (scores[perfume.occasion]) {
          matchScore += scores[perfume.occasion] * 1.5;
        }
        
        // Season matching
        if (scores[perfume.season]) {
          matchScore += scores[perfume.season] * 1.2;
        }
        
        return { perfume, matchScore };
      })
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, 3)
      .map(item => item.perfume);

    // Determine personality type
    const topCategory = Object.entries(scores).reduce((a, b) => 
      scores[a[0]] > scores[b[0]] ? a : b
    )[0];
    
    const personalityMap = {
      floral: {
        type: 'The Romantic',
        description: 'You are drawn to beauty and elegance. Floral fragrances speak to your gentle, nurturing nature and your appreciation for life\'s finer moments.',
        icon: '🌸'
      },
      fresh: {
        type: 'The Free Spirit',
        description: 'You love adventure and spontaneity. Fresh, clean scents match your optimistic outlook and your desire to embrace each day with enthusiasm.',
        icon: '🌊'
      },
      woody: {
        type: 'The Sophisticate',
        description: 'You value depth and authenticity. Woody fragrances reflect your grounded nature and your appreciation for timeless elegance.',
        icon: '🌲'
      },
      oriental: {
        type: 'The Enigma',
        description: 'You are mysterious and captivating. Oriental fragrances match your complex personality and your ability to leave a lasting impression.',
        icon: '✨'
      },
      citrus: {
        type: 'The Energizer',
        description: 'You are vibrant and uplifting. Citrus scents mirror your positive energy and your ability to brighten any room you enter.',
        icon: '🍋'
      }
    };

    const personality = personalityMap[topCategory] || personalityMap.floral;

    const quizResult = {
      recommendations: matchedPerfumes,
      personality: personality.type,
      description: personality.description,
      icon: personality.icon
    };

    setResults(quizResult);
    setShowResults(true);

    // Save quiz result to database if user is logged in
    if (user) {
      const saveQuizResult = async () => {
        try {
          await quizService.saveQuizResult(
            user.id,
            answers,
            personality.type,
            matchedPerfumes.map(p => p.id)
          );
        } catch (error) {
          console.error('Error saving quiz result:', error);
        }
      };
      saveQuizResult();
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
    setResults(null);
  };

  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;

  if (showResults && results) {
    return (
      <section className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-amber-50 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-up">
            <div className="glass rounded-full px-8 py-4 mb-8 inline-flex items-center space-x-3">
              <Award className="w-6 h-6 text-purple-600" />
              <span className="font-semibold text-purple-800 text-lg">Quiz Results</span>
              <Sparkles className="w-6 h-6 text-amber-500" />
            </div>
            
            <div className="text-6xl mb-4 animate-scale-in">{results.icon}</div>
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 text-gradient">
              You are {results.personality}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              {results.description}
            </p>
          </div>

          <div className="mb-16">
            <h3 className="text-3xl font-bold text-center text-gray-900 mb-12 animate-fade-in-up">
              Your Perfect Fragrance Matches
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {results.recommendations.map((perfume, index) => (
                <div key={perfume.id} className={`relative animate-fade-in-up stagger-${index + 1}`}>
                  {index === 0 && (
                    <div className="absolute -top-4 -right-4 bg-gradient-to-r from-purple-600 to-amber-500 text-white rounded-full w-12 h-12 flex items-center justify-center text-lg font-bold z-10 animate-pulse-glow">
                      #1
                    </div>
                  )}
                  <ProductCard
                    perfume={perfume}
                    onAddToCart={onAddToCart}
                    onAddToWishlist={onAddToWishlist}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="text-center animate-fade-in-up">
            <button
              onClick={resetQuiz}
              className="inline-flex items-center space-x-3 px-10 py-5 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-full font-semibold text-lg shadow-2xl hover-lift hover-glow transition-all duration-500"
            >
              <RefreshCw className="w-6 h-6" />
              <span>Take Quiz Again</span>
            </button>
          </div>
        </div>
      </section>
    );
  }

  const question = quizQuestions[currentQuestion];
  const selectedAnswer = answers[question.id];

  return (
    <section className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-amber-50 py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Progress Bar */}
        <div className="mb-12 animate-fade-in-down">
          <div className="flex justify-between text-sm text-gray-600 mb-4">
            <span className="font-medium">Question {currentQuestion + 1} of {quizQuestions.length}</span>
            <span className="font-medium">{Math.round(progress)}% Complete</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-purple-600 to-amber-500 h-3 rounded-full transition-all duration-700 ease-out animate-shimmer"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question Card */}
        <div className="glass rounded-3xl shadow-2xl p-8 md:p-12 mb-12 animate-scale-in">
          <div className="text-center mb-10">
            <div className="glass rounded-full px-6 py-3 mb-6 inline-flex items-center space-x-2">
              <Heart className="w-5 h-5 text-purple-600" />
              <span className="text-sm font-medium text-purple-800 capitalize">
                {question.category}
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight text-shadow">
              {question.question}
            </h2>
          </div>

          <div className="space-y-4">
            {question.options.map((option, index) => (
              <button
                key={option.id}
                onClick={() => handleAnswer(question.id, option.id)}
                className={`w-full p-6 rounded-2xl border-2 transition-all duration-500 text-left hover-lift animate-fade-in-up stagger-${index + 1} ${
                  selectedAnswer === option.id
                    ? 'border-purple-500 bg-gradient-to-r from-purple-50 to-amber-50 shadow-xl animate-pulse-glow'
                    : 'border-gray-200 hover:border-purple-300 hover:bg-purple-25 glass'
                }`}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                    selectedAnswer === option.id
                      ? 'border-purple-500 bg-purple-500 animate-scale-in'
                      : 'border-gray-300'
                  }`}>
                    {selectedAnswer === option.id && (
                      <div className="w-3 h-3 bg-white rounded-full animate-scale-in" />
                    )}
                  </div>
                  <span className="text-lg font-medium text-gray-800">
                    {option.text}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center animate-fade-in-up">
          <button
            onClick={prevQuestion}
            disabled={currentQuestion === 0}
            className={`flex items-center space-x-2 px-8 py-4 rounded-full font-semibold transition-all duration-300 ${
              currentQuestion === 0
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'glass text-gray-700 hover:bg-white/50 shadow-lg hover-lift'
            }`}
          >
            <ChevronLeft className="w-5 h-5" />
            <span>Previous</span>
          </button>

          <button
            onClick={nextQuestion}
            disabled={!selectedAnswer}
            className={`flex items-center space-x-2 px-8 py-4 rounded-full font-semibold transition-all duration-500 ${
              !selectedAnswer
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-600 to-purple-700 text-white hover-lift hover-glow shadow-2xl'
            }`}
          >
            <span>
              {currentQuestion === quizQuestions.length - 1 ? 'See Results' : 'Next'}
            </span>
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Quiz;