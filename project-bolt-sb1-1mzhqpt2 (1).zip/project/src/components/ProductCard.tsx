import React, { useState } from 'react';
import { Heart, ShoppingBag, Star, Eye } from 'lucide-react';
import { Perfume } from '../types';

interface ProductCardProps {
  perfume: Perfume;
  onAddToCart: (perfume: Perfume) => void;
  onAddToWishlist: (perfume: Perfume) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  perfume, 
  onAddToCart, 
  onAddToWishlist 
}) => {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  const handleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    onAddToWishlist(perfume);
  };

  const handleAddToCart = () => {
    onAddToCart(perfume);
  };

  return (
    <div className="group relative bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden">
      {/* Sale Badge */}
      {perfume.originalPrice && (
        <div className="absolute top-4 left-4 bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-semibold z-10">
          Save ${perfume.originalPrice - perfume.price}
        </div>
      )}

      {/* Wishlist Button */}
      <button
        onClick={handleWishlist}
        className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md hover:shadow-lg transition-all duration-300 z-10"
      >
        <Heart 
          className={`w-5 h-5 transition-colors duration-300 ${
            isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'
          }`}
        />
      </button>

      {/* Product Image */}
      <div className="relative h-80 overflow-hidden">
        <img
          src={perfume.image}
          alt={perfume.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Quick View Button */}
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-white/90 backdrop-blur-sm text-gray-800 px-4 py-2 rounded-full font-semibold flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-white"
        >
          <Eye className="w-4 h-4" />
          <span>Quick View</span>
        </button>
      </div>

      {/* Product Info */}
      <div className="p-6">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-1">{perfume.name}</h3>
            <p className="text-sm text-gray-600 uppercase tracking-wide">{perfume.brand}</p>
          </div>
          <div className="flex items-center space-x-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-medium text-gray-700">{perfume.rating}</span>
            <span className="text-sm text-gray-500">({perfume.reviews})</span>
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{perfume.description}</p>

        {/* Fragrance Notes */}
        <div className="mb-4">
          <div className="flex flex-wrap gap-1 mb-2">
            {perfume.notes.top.slice(0, 3).map((note, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs font-medium"
              >
                {note}
              </span>
            ))}
          </div>
        </div>

        {/* Category & Intensity */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <span className="px-2 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-medium capitalize">
              {perfume.category}
            </span>
            <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium capitalize">
              {perfume.intensity}
            </span>
          </div>
          {!perfume.inStock && (
            <span className="text-red-500 text-sm font-medium">Out of Stock</span>
          )}
        </div>

        {/* Price */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <span className="text-2xl font-bold text-gray-900">${perfume.price}</span>
            {perfume.originalPrice && (
              <span className="text-lg text-gray-500 line-through">
                ${perfume.originalPrice}
              </span>
            )}
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleAddToCart}
          disabled={!perfume.inStock}
          className={`w-full flex items-center justify-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
            perfume.inStock
              ? 'bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:shadow-lg transform hover:-translate-y-1'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          <ShoppingBag className="w-5 h-5" />
          <span>{perfume.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
        </button>
      </div>

      {/* Extended Details Modal */}
      {showDetails && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-2xl font-bold text-gray-900">{perfume.name}</h2>
                <button
                  onClick={() => setShowDetails(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <img
                  src={perfume.image}
                  alt={perfume.name}
                  className="w-full h-64 object-cover rounded-2xl"
                />
                
                <div>
                  <p className="text-gray-600 mb-4">{perfume.description}</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Top Notes</h4>
                      <div className="flex flex-wrap gap-1">
                        {perfume.notes.top.map((note, index) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Middle Notes</h4>
                      <div className="flex flex-wrap gap-1">
                        {perfume.notes.middle.map((note, index) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-amber-100 text-amber-800 rounded-full text-xs"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Base Notes</h4>
                      <div className="flex flex-wrap gap-1">
                        {perfume.notes.base.map((note, index) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200">
                <button
                  onClick={() => {
                    handleAddToCart();
                    setShowDetails(false);
                  }}
                  disabled={!perfume.inStock}
                  className={`w-full flex items-center justify-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                    perfume.inStock
                      ? 'bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:shadow-lg'
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>{perfume.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductCard;