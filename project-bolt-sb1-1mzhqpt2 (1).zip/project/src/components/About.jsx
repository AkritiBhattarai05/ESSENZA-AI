import React from 'react';
import { Award, Heart, Sparkles, Users, Star, Globe } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: <Heart className="w-8 h-8 text-purple-600" />,
      title: 'Crafted with Passion',
      description: 'Each fragrance is carefully developed by master perfumers who understand the art of scent creation.'
    },
    {
      icon: <Award className="w-8 h-8 text-purple-600" />,
      title: 'Premium Quality',
      description: 'We use only the finest ingredients sourced from around the world to ensure exceptional quality.'
    },
    {
      icon: <Sparkles className="w-8 h-8 text-purple-600" />,
      title: 'Unique Blends',
      description: 'Our signature fragrances are exclusive compositions that you won\'t find anywhere else.'
    },
    {
      icon: <Users className="w-8 h-8 text-purple-600" />,
      title: 'Personal Journey',
      description: 'We believe every person deserves a signature scent that tells their unique story.'
    }
  ];

  const stats = [
    { icon: <Globe className="w-8 h-8" />, number: '50+', label: 'Countries Served' },
    { icon: <Users className="w-8 h-8" />, number: '100K+', label: 'Happy Customers' },
    { icon: <Star className="w-8 h-8" />, number: '4.9', label: 'Average Rating' },
    { icon: <Award className="w-8 h-8" />, number: '25+', label: 'Awards Won' }
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-amber-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-20 animate-fade-in-up">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 text-gradient">
            About ESSENZA
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Founded with a passion for the art of perfumery, ESSENZA represents the perfect harmony between tradition and innovation. We believe that fragrance is more than just a scent—it's a personal signature, a memory, and an emotion captured in a bottle.
          </p>
        </div>

        {/* Hero Image */}
        <div className="mb-20 animate-fade-in-up stagger-2">
          <div className="relative h-96 rounded-3xl overflow-hidden shadow-2xl">
            <img
              src="https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=1920"
              alt="Perfume bottles in elegant setting"
              className="w-full h-full object-cover hover-scale"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            <div className="absolute bottom-8 left-8 text-white animate-slide-in-left">
              <h2 className="text-4xl font-bold mb-3 text-shadow">The Art of Scent</h2>
              <p className="text-xl opacity-90">Where luxury meets craftsmanship</p>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mb-20 animate-fade-in-up stagger-3">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className={`text-center glass rounded-2xl p-6 hover-lift animate-fade-in-up stagger-${index + 1}`}>
                <div className="text-purple-600 mb-4 flex justify-center">
                  {stat.icon}
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20 animate-fade-in-up stagger-4">
          {features.map((feature, index) => (
            <div key={index} className={`bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-500 hover-lift animate-fade-in-up stagger-${index + 1}`}>
              <div className="mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Story Section */}
        <div className="bg-white rounded-3xl p-8 md:p-16 shadow-2xl mb-20 animate-fade-in-up stagger-5">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-10 text-center text-gradient">
              Our Story
            </h2>
            <div className="space-y-8 text-lg text-gray-700 leading-relaxed">
              <p className="animate-fade-in-up stagger-1">
                ESSENZA was born from a simple yet profound belief: that every person has a unique essence that deserves to be celebrated through fragrance. Our journey began in the heart of Grasse, France, where we learned the ancient art of perfumery from master craftsmen who had dedicated their lives to creating olfactory masterpieces.
              </p>
              <p className="animate-fade-in-up stagger-2">
                What sets us apart is our commitment to personalization. We understand that choosing a fragrance is deeply personal—it's about finding a scent that resonates with your soul, complements your personality, and becomes an integral part of your identity. That's why we developed our intelligent fragrance quiz, designed to understand your preferences and guide you to your perfect match.
              </p>
              <p className="animate-fade-in-up stagger-3">
                Today, ESSENZA continues to push the boundaries of traditional perfumery, combining time-honored techniques with modern innovation. Each bottle in our collection tells a story, evokes an emotion, and creates a lasting impression that goes far beyond the initial spray.
              </p>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="text-center animate-fade-in-up stagger-6">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-gradient">
            Our Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-purple-100 to-purple-200 rounded-3xl p-8 hover-lift animate-fade-in-up stagger-1">
              <h3 className="text-2xl font-bold text-purple-900 mb-4">Authenticity</h3>
              <p className="text-purple-800 leading-relaxed">
                We believe in creating genuine, original fragrances that reflect true artistry and craftsmanship.
              </p>
            </div>
            <div className="bg-gradient-to-br from-amber-100 to-amber-200 rounded-3xl p-8 hover-lift animate-fade-in-up stagger-2">
              <h3 className="text-2xl font-bold text-amber-900 mb-4">Quality</h3>
              <p className="text-amber-800 leading-relaxed">
                Only the finest ingredients make it into our bottles, ensuring exceptional quality in every spray.
              </p>
            </div>
            <div className="bg-gradient-to-br from-purple-100 to-amber-100 rounded-3xl p-8 hover-lift animate-fade-in-up stagger-3">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Innovation</h3>
              <p className="text-gray-800 leading-relaxed">
                We continuously explore new frontiers in fragrance creation while respecting traditional techniques.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;