import React, { useState } from 'react';
import { Heart, ShoppingBag, Star, Eye, Sparkles } from 'lucide-react';

const ProductCard = ({ perfume, onAddToCart, onAddToWishlist }) => {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  const handleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    onAddToWishlist(perfume);
  };

  const handleAddToCart = () => {
    onAddToCart(perfume);
  };

  return (
    <div className="group relative bg-white rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden hover-lift">
      {/* Sale Badge */}
      {perfume.originalPrice && (
        <div className="absolute top-4 left-4 bg-gradient-to-r from-red-500 to-pink-500 text-white px-4 py-2 rounded-full text-sm font-bold z-10 animate-pulse-glow">
          Save ${perfume.originalPrice - perfume.price}
        </div>
      )}

      {/* Wishlist Button */}
      <button
        onClick={handleWishlist}
        className="absolute top-4 right-4 w-12 h-12 glass rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 z-10 hover-scale"
      >
        <Heart 
          className={`w-6 h-6 transition-all duration-300 ${
            isWishlisted ? 'fill-red-500 text-red-500 animate-pulse' : 'text-gray-600'
          }`}
        />
      </button>

      {/* Product Image */}
      <div className="relative h-80 overflow-hidden">
        <img
          src={perfume.image}
          alt={perfume.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Quick View Button */}
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="absolute bottom-4 left-1/2 transform -translate-x-1/2 glass text-white px-6 py-3 rounded-full font-semibold flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-all duration-500 hover-scale"
        >
          <Eye className="w-5 h-5" />
          <span>Quick View</span>
        </button>
      </div>

      {/* Product Info */}
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">{perfume.name}</h3>
            <p className="text-sm text-gray-600 uppercase tracking-wide font-medium">{perfume.brand}</p>
          </div>
          <div className="flex items-center space-x-1 glass rounded-full px-3 py-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-bold text-gray-700">{perfume.rating}</span>
            <span className="text-xs text-gray-500">({perfume.reviews})</span>
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-4 line-clamp-2 leading-relaxed">{perfume.description}</p>

        {/* Fragrance Notes */}
        <div className="mb-4">
          <div className="flex flex-wrap gap-2 mb-3">
            {perfume.notes.top.slice(0, 3).map((note, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-gradient-to-r from-purple-100 to-purple-200 text-purple-800 rounded-full text-xs font-medium"
              >
                {note}
              </span>
            ))}
          </div>
        </div>

        {/* Category & Intensity */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <span className="px-3 py-1 bg-gradient-to-r from-amber-100 to-amber-200 text-amber-800 rounded-full text-xs font-medium capitalize">
              {perfume.category}
            </span>
            <span className="px-3 py-1 glass text-gray-800 rounded-full text-xs font-medium capitalize">
              {perfume.intensity}
            </span>
          </div>
          {!perfume.inStock && (
            <span className="text-red-500 text-sm font-bold animate-pulse">Out of Stock</span>
          )}
        </div>

        {/* Price */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <span className="text-3xl font-bold text-gray-900">${perfume.price}</span>
            {perfume.originalPrice && (
              <span className="text-lg text-gray-500 line-through">
                ${perfume.originalPrice}
              </span>
            )}
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleAddToCart}
          disabled={!perfume.inStock}
          className={`w-full flex items-center justify-center space-x-3 px-6 py-4 rounded-full font-semibold transition-all duration-500 ${
            perfume.inStock
              ? 'bg-gradient-to-r from-purple-600 to-purple-700 text-white hover-lift hover-glow shadow-xl'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          <ShoppingBag className="w-5 h-5" />
          <span>{perfume.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
          {perfume.inStock && <Sparkles className="w-4 h-4" />}
        </button>
      </div>

      {/* Extended Details Modal */}
      {showDetails && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in-up">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-scale-in">
            <div className="p-8">
              <div className="flex justify-between items-start mb-6">
                <h2 className="text-3xl font-bold text-gray-900 text-gradient">{perfume.name}</h2>
                <button
                  onClick={() => setShowDetails(false)}
                  className="text-gray-400 hover:text-gray-600 text-3xl font-light hover-scale"
                >
                  ×
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="relative">
                  <img
                    src={perfume.image}
                    alt={perfume.name}
                    className="w-full h-80 object-cover rounded-2xl shadow-xl"
                  />
                  <div className="absolute top-4 right-4 glass rounded-full px-4 py-2">
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-bold">{perfume.rating}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <p className="text-gray-600 mb-6 text-lg leading-relaxed">{perfume.description}</p>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 flex items-center space-x-2">
                        <span>Top Notes</span>
                        <Sparkles className="w-4 h-4 text-purple-500" />
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {perfume.notes.top.map((note, index) => (
                          <span
                            key={index}
                            className="px-3 py-1 bg-gradient-to-r from-purple-100 to-purple-200 text-purple-800 rounded-full text-sm font-medium"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 flex items-center space-x-2">
                        <span>Middle Notes</span>
                        <Heart className="w-4 h-4 text-pink-500" />
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {perfume.notes.middle.map((note, index) => (
                          <span
                            key={index}
                            className="px-3 py-1 bg-gradient-to-r from-amber-100 to-amber-200 text-amber-800 rounded-full text-sm font-medium"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-bold text-gray-900 mb-3">Base Notes</h4>
                      <div className="flex flex-wrap gap-2">
                        {perfume.notes.base.map((note, index) => (
                          <span
                            key={index}
                            className="px-3 py-1 glass text-gray-800 rounded-full text-sm font-medium"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 p-4 glass rounded-2xl">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-3xl font-bold text-gray-900">${perfume.price}</span>
                        {perfume.originalPrice && (
                          <span className="text-lg text-gray-500 line-through ml-2">
                            ${perfume.originalPrice}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="px-3 py-1 bg-gradient-to-r from-amber-100 to-amber-200 text-amber-800 rounded-full text-sm font-medium capitalize">
                          {perfume.category}
                        </span>
                        <span className="px-3 py-1 glass text-gray-800 rounded-full text-sm font-medium capitalize">
                          {perfume.intensity}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 pt-6 border-t border-gray-200">
                <button
                  onClick={() => {
                    handleAddToCart();
                    setShowDetails(false);
                  }}
                  disabled={!perfume.inStock}
                  className={`w-full flex items-center justify-center space-x-3 px-8 py-4 rounded-full font-bold text-lg transition-all duration-500 ${
                    perfume.inStock
                      ? 'bg-gradient-to-r from-purple-600 to-purple-700 text-white hover-lift hover-glow shadow-2xl'
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  <ShoppingBag className="w-6 h-6" />
                  <span>{perfume.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
                  {perfume.inStock && <Sparkles className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductCard;