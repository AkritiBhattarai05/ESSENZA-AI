import React from 'react';
import { Sparkles, ArrowRight, Star } from 'lucide-react';

const Hero = ({ onStartQuiz, onViewProducts }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-purple-800 to-amber-900 animate-gradient">
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=1920')] bg-cover bg-center opacity-20" />
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white/10 animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${Math.random() * 6 + 2}px`,
              height: `${Math.random() * 6 + 2}px`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${Math.random() * 4 + 3}s`
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="glass rounded-full px-6 py-3 mb-8 inline-flex items-center space-x-2 animate-fade-in-down">
          <Sparkles className="w-5 h-5 text-amber-400 animate-pulse" />
          <span className="text-sm font-medium text-white">Discover Your Signature Scent</span>
          <Star className="w-4 h-4 text-amber-400" />
        </div>

        <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-8 leading-tight animate-fade-in-up">
          <span className="text-gradient bg-gradient-to-r from-white via-purple-200 to-amber-200 bg-clip-text text-transparent">
            ESSENZA
          </span>
          <br />
          <span className="text-2xl md:text-4xl lg:text-5xl font-light text-white/90 animate-fade-in-up stagger-2">
            Where Luxury Meets Soul
          </span>
        </h1>

        <p className="text-xl md:text-2xl text-white/80 mb-12 max-w-3xl mx-auto leading-relaxed animate-fade-in-up stagger-3">
          Embark on a sensory journey through our curated collection of premium fragrances.
          Let our intelligent quiz guide you to your perfect scent match.
        </p>

        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center animate-fade-in-up stagger-4">
          <button
            onClick={onStartQuiz}
            className="group relative px-10 py-5 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-full font-semibold text-xl shadow-2xl hover-lift hover-glow transition-all duration-500 overflow-hidden"
          >
            <span className="relative z-10 flex items-center space-x-3">
              <Sparkles className="w-6 h-6" />
              <span>Take the Quiz</span>
              <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform duration-300" />
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </button>

          <button
            onClick={onViewProducts}
            className="group px-10 py-5 glass text-white rounded-full font-semibold text-xl border-2 border-white/30 hover:bg-white/20 hover:border-white/50 hover-lift transition-all duration-500"
          >
            <span className="flex items-center space-x-3">
              <span>View Collection</span>
              <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform duration-300" />
            </span>
          </button>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-3 gap-8 max-w-2xl mx-auto animate-fade-in-up stagger-5">
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">50+</div>
            <div className="text-white/70 text-sm">Premium Fragrances</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">10K+</div>
            <div className="text-white/70 text-sm">Happy Customers</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">4.9★</div>
            <div className="text-white/70 text-sm">Average Rating</div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/40 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/60 rounded-full mt-2 animate-pulse" />
        </div>
      </div>
    </section>
  );
};

export default Hero;