import React, { useState } from 'react';
import { ChevronRight, ChevronLeft, Sparkles, Heart, RefreshCw } from 'lucide-react';
import { quizQuestions } from '../data/quiz';
import { perfumes } from '../data/perfumes';
import { QuizResult, Perfume } from '../types';
import ProductCard from './ProductCard';

interface QuizProps {
  onAddToCart: (perfume: Perfume) => void;
  onAddToWishlist: (perfume: Perfume) => void;
}

const Quiz: React.FC<QuizProps> = ({ onAddToCart, onAddToWishlist }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState<QuizResult | null>(null);

  const handleAnswer = (questionId: string, optionId: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: optionId }));
  };

  const nextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResults();
    }
  };

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const calculateResults = () => {
    const scores: Record<string, number> = {};
    
    Object.entries(answers).forEach(([questionId, optionId]) => {
      const question = quizQuestions.find(q => q.id === questionId);
      const option = question?.options.find(o => o.id === optionId);
      
      if (option) {
        Object.entries(option.weight).forEach(([key, value]) => {
          scores[key] = (scores[key] || 0) + value;
        });
      }
    });

    // Find matching perfumes based on scores
    const matchedPerfumes = perfumes
      .map(perfume => {
        let matchScore = 0;
        
        // Category matching
        if (scores[perfume.category]) {
          matchScore += scores[perfume.category] * 2;
        }
        
        // Intensity matching
        if (scores[perfume.intensity]) {
          matchScore += scores[perfume.intensity] * 1.5;
        }
        
        // Occasion matching
        if (scores[perfume.occasion]) {
          matchScore += scores[perfume.occasion] * 1.5;
        }
        
        // Season matching
        if (scores[perfume.season]) {
          matchScore += scores[perfume.season] * 1.2;
        }
        
        return { perfume, matchScore };
      })
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, 3)
      .map(item => item.perfume);

    // Determine personality type
    const topCategory = Object.entries(scores).reduce((a, b) => 
      scores[a[0]] > scores[b[0]] ? a : b
    )[0];
    
    const personalityMap: Record<string, { type: string; description: string }> = {
      floral: {
        type: 'The Romantic',
        description: 'You are drawn to beauty and elegance. Floral fragrances speak to your gentle, nurturing nature and your appreciation for life\'s finer moments.'
      },
      fresh: {
        type: 'The Free Spirit',
        description: 'You love adventure and spontaneity. Fresh, clean scents match your optimistic outlook and your desire to embrace each day with enthusiasm.'
      },
      woody: {
        type: 'The Sophisticate',
        description: 'You value depth and authenticity. Woody fragrances reflect your grounded nature and your appreciation for timeless elegance.'
      },
      oriental: {
        type: 'The Enigma',
        description: 'You are mysterious and captivating. Oriental fragrances match your complex personality and your ability to leave a lasting impression.'
      },
      citrus: {
        type: 'The Energizer',
        description: 'You are vibrant and uplifting. Citrus scents mirror your positive energy and your ability to brighten any room you enter.'
      }
    };

    const personality = personalityMap[topCategory] || personalityMap.floral;

    setResults({
      recommendations: matchedPerfumes,
      personality: personality.type,
      description: personality.description
    });
    setShowResults(true);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
    setResults(null);
  };

  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;

  if (showResults && results) {
    return (
      <section className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-amber-50 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-amber-500 text-white rounded-full px-6 py-3 mb-6">
              <Sparkles className="w-5 h-5" />
              <span className="font-semibold">Quiz Results</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              You are {results.personality}
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
              {results.description}
            </p>
          </div>

          <div className="mb-12">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">
              Your Perfect Fragrance Matches
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {results.recommendations.map((perfume, index) => (
                <div key={perfume.id} className="relative">
                  {index === 0 && (
                    <div className="absolute -top-3 -right-3 bg-gradient-to-r from-purple-600 to-amber-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold z-10">
                      1
                    </div>
                  )}
                  <ProductCard
                    perfume={perfume}
                    onAddToCart={onAddToCart}
                    onAddToWishlist={onAddToWishlist}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="text-center">
            <button
              onClick={resetQuiz}
              className="inline-flex items-center space-x-2 px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-full font-semibold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
            >
              <RefreshCw className="w-5 h-5" />
              <span>Take Quiz Again</span>
            </button>
          </div>
        </div>
      </section>
    );
  }

  const question = quizQuestions[currentQuestion];
  const selectedAnswer = answers[question.id];

  return (
    <section className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-amber-50 py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Question {currentQuestion + 1} of {quizQuestions.length}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-purple-600 to-amber-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12 mb-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-purple-100 to-amber-100 rounded-full px-4 py-2 mb-4">
              <Heart className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-800 capitalize">
                {question.category}
              </span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 leading-tight">
              {question.question}
            </h2>
          </div>

          <div className="space-y-4">
            {question.options.map((option) => (
              <button
                key={option.id}
                onClick={() => handleAnswer(question.id, option.id)}
                className={`w-full p-6 rounded-2xl border-2 transition-all duration-300 text-left ${
                  selectedAnswer === option.id
                    ? 'border-purple-500 bg-purple-50 shadow-lg'
                    : 'border-gray-200 hover:border-purple-300 hover:bg-purple-25'
                }`}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    selectedAnswer === option.id
                      ? 'border-purple-500 bg-purple-500'
                      : 'border-gray-300'
                  }`}>
                    {selectedAnswer === option.id && (
                      <div className="w-2 h-2 bg-white rounded-full" />
                    )}
                  </div>
                  <span className="text-lg font-medium text-gray-800">
                    {option.text}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <button
            onClick={prevQuestion}
            disabled={currentQuestion === 0}
            className={`flex items-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
              currentQuestion === 0
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-white text-gray-700 hover:bg-gray-50 shadow-md hover:shadow-lg'
            }`}
          >
            <ChevronLeft className="w-5 h-5" />
            <span>Previous</span>
          </button>

          <button
            onClick={nextQuestion}
            disabled={!selectedAnswer}
            className={`flex items-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
              !selectedAnswer
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:shadow-lg transform hover:-translate-y-1'
            }`}
          >
            <span>
              {currentQuestion === quizQuestions.length - 1 ? 'See Results' : 'Next'}
            </span>
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Quiz;